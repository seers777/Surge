/*
微商相册自慰
https:\/\/www\.wsxcme\.com\/service\/account\/user_info_operation

hostname：*.wsxcme.com
let obj = JSON.parse($response.body);

    obj. result.is_vip = true,
    obj. result.is_expire = false,
    obj. result.deadline = "2029-02-13",
   

$done({body: JSON.stringify(obj)});
